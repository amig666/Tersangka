        # SPAM CALL BRUTAL #
        
        
[] BY BARTES DWIKY
[] INSTAGRAM : @bartes_07
[] Whatsapp  : +6281949028199
[] Region   : Bangka Selatan ( Toboali ) 
